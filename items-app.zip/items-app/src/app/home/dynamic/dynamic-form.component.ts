import { Component, OnInit, Input } from '@angular/core'; 
import { FormGroup, FormControl,Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.css']
})
export class DynamicFormComponent  implements OnInit {
  title = 'items-app';

     dynamicForm:FormGroup;
     @Input() formTemplate: any; 
     constructor(private route: ActivatedRoute) {}  
       
     ngOnInit() {
       this.loadDynamicForm();
     }

     loadDynamicForm(){
      let group={};   
       this.formTemplate.forEach(input_template=>{
         group["field"+input_template]=new FormControl('');  
       })
       this.dynamicForm = new FormGroup(group);
     }

     callFromParent(id){
       this.formTemplate = [];
       for(let count=1; count <= id *2; count++ ){
        this.formTemplate.push(count);
       }
       this.loadDynamicForm();
     }

     onSubmit(){
       console.log(this.dynamicForm.value);
     }
}

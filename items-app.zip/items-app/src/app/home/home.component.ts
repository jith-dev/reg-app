import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription, fromEvent } from 'rxjs';
import { DynamicFormComponent } from './dynamic/dynamic-form.component';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  title = 'items-app';
  itemsno : string ;
  idelStart: any= null;
  subscription: Subscription;
  itemList: any = [];
  templateFormList: any = [];
  @ViewChild(DynamicFormComponent) child:DynamicFormComponent;

  constructor(private router: Router) {

     }

  ngOnInit(): void {
   this.setSessionTimer();
   this.subscription = 
         fromEvent(document, 'mousemove')
                           .subscribe(e => {
                             clearInterval(this.idelStart);
                             this.setSessionTimer();
                           });
  }

   setSessionTimer(){
    this.idelStart =setInterval( ()=>{
      clearInterval(this.idelStart);
      this.router.navigate(['/']);
  },300000);
   }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }

  generate(){
  this.itemList = [];
  this.templateFormList = [];
   for(let count=1; count <= +this.itemsno; count++ ){
      let item = {};
      item["itemId"] = +this.genRandomNumber();
      item["itemLabel"] = 'Item'+' ' + count;
      item["id"] = count;

      this.itemList.push(item);
   }
   for(let count=1; count <= this.itemList.length *2; count++ ){
    this.templateFormList.push(count);
   }
   this.router.navigate(['/home']);
  }

  genRandomNumber() : number { 
    var minm = 10000; 
    var maxm = 99999; 
    return (Math.floor(Math 
    .random() * (maxm - minm + 1)) + minm); 
} 

  navigate(count: number){
   this.router.navigate(['/home/item', count]);
   this.child.callFromParent(count);
}
  logOut(): void {
    this.router.navigate(['/login']);
  }

}

import { Component, OnInit} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { UserService } from './user.service'
import { DataService } from '../data.service'

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  title = 'reg-app';
  userData: any;
  genderTypes: string[] = ['Male', 'Female'];
  userForm: any;

  constructor(private formBuilder: FormBuilder, private user: UserService,
     private sharedData: DataService) { }

  ngOnInit() {
    this.userForm = this.formBuilder.group({
      first: ['', [Validators.required]],
      last: [''],
      title: [''],
      gender: [''],
      email: ['', [Validators.required, Validators.email]],
      phone: [''],
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });

    this.user.getUsers().subscribe((data:any) => {
      this.userData = data;
    });
  }

  onCreate() {
    if (this.userForm.valid) {
      this.user.getUsers().subscribe((data:any) => {
      debugger;
      console.log(data.results.push({ user: {
        name : {
          title:this.userForm.value.title,
          first:this.userForm.value.first,
          last:this.userForm.value.last,
        },
        phone: this.userForm.value.phone,
        email: this.userForm.value.email,
        username: this.userForm.value.username,
        password: this.userForm.value.password,
      }
    }));
        this.sharedData.changeMessage(JSON.stringify(data.results));
      });

       }
  }

  changeGender(e) {
    this.gender.setValue(e.target.value, {
      onlySelf: true
    })
  }  

  get gender() {
    return this.userForm.get('gender');
  }

}

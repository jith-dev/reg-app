import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
import { DataService } from '../data.service'

export interface Interest {
  name: string;
}

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  title = 'reg-app';
  isRegisterForm: boolean = false;
  url: string = '';
  userForm: any;
  cities: string[] = ['Alaska', 'Kochi', 'Newyork'];
  countries: string[] = ['USA', 'India', 'Germany'];
  addressTypes: string[] = ['Home', 'Office'];
  typeOfAddress: string = '';

  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  interests: Interest[] = [];

  cardImageBase64: string = '';

  constructor(private formBuilder: FormBuilder, private route: ActivatedRoute,
    private router: Router, private data: DataService) { }

  ngOnInit() {
    this.userForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.maxLength(20), Validators.pattern('^[a-zA-Z ]*$')]],
      lastName: [''],
      age: 0,
      email: ['', [Validators.required, Validators.email]],
      telephone: [''],
      cityName: [''],
      countryName: [''],
      addressType: [''],
      address1: ['', [Validators.maxLength(45)]],
      address2: ['', [Validators.maxLength(45)]],
      interests: [this.interests],
      subscribe: [false],
      imageBase64: [''],
    });

    const id = +this.route.snapshot.paramMap.get('id');
    if (id == 1) {
      this.data.currentMessage.subscribe(data => {
        console.log(JSON.parse(data));
        const personalInfo = JSON.parse(data);
        this.cardImageBase64 = personalInfo["imageBase64"];
        this.interests = personalInfo["interests"];
        this.userForm.patchValue({
          firstName: personalInfo.firstName,
          lastName: personalInfo['lastName'],
          email: personalInfo['email'],
          telephone: personalInfo['telephone'],
          age: personalInfo['age'],
          cityName: personalInfo['cityName'],
          countryName: personalInfo['countryName'],
          addressType: personalInfo['addressType'],
          address1: personalInfo['address1'],
          address2: personalInfo['address2'],
          subscribe: personalInfo['subscribe'],
        });
        console.log(JSON.parse(data).interests);
      });
    }
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our interest
    if ((value || '').trim()) {
      this.interests.push({ name: value.trim() });
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  remove(interest: Interest): void {
    const index = this.interests.indexOf(interest);

    if (index >= 0) {
      this.interests.splice(index, 1);
    }
  }

  onSubmit() {
    if (this.userForm.valid) {
      this.userForm.patchValue({
        imageBase64: this.cardImageBase64,
        interests: this.interests,
      });
      this.data.changeMessage(JSON.stringify(this.userForm.value));
      this.router.navigate(['/profile']);
    }
  }

  changeCity(e) {
    this.cityName.setValue(e.target.value, {
      onlySelf: true
    })
  }

  get cityName() {
    return this.userForm.get('cityName');
  }

  changeCountry(e) {
    this.countryName.setValue(e.target.value, {
      onlySelf: true
    })
  }

  get countryName() {
    return this.userForm.get('countryName');
  }

  changeAddressType(e) {
    if (e.target.value != '') {
      let addr = e.target.value.split(':')[1].trim();
      this.typeOfAddress = (addr == "Home" || "Office") ? addr : '';
    } else { this.typeOfAddress = ''; }
    this.addressType.setValue(e.target.value, {
      onlySelf: true
    })

  }

  get addressType() {
    return this.userForm.get('addressType');
  }

  onselectFile(e: any): void {
    if (e.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      reader.onload = (event: any) => {
        this.url = event.target.result;
        const imgBase64Path = event.target.result;
        this.cardImageBase64 = imgBase64Path;
      }
    }
  }

}

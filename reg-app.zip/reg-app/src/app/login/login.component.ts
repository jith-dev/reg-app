import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../data.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  title = 'reg-app';
  profileData: string;
  name: string;
  email: string;
  telephone: string;
  place: string;
  personalInterest: string;
  age: string;
  imageBase64: string;
  loginForm: any;
  userCredentials: any = {
    'username': 'admin',
    'password': 'password'
  }

  constructor(private formBuilder: FormBuilder, private data: DataService, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]]
    });
  }

  onLogin() {
    if (this.loginForm.valid) {
      if(this.userCredentials.username == this.loginForm.value.username
           && this.userCredentials.password == this.loginForm.value.password)
      this.router.navigate(['/home']);
    }
  }

  editProfile(): void {
    let jsonData = JSON.parse(this.profileData);
    jsonData.imageBase64 = this.imageBase64;
    console.log(jsonData);
    this.data.changeMessage(JSON.stringify(jsonData));
    this.router.navigate(['/edit', 1]);
  }

  onselectFile(e: any): void {
    if (e.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      this.imageBase64 = '';
      reader.onload = (event: any) => {
        this.imageBase64 = event.target.result;
      }
    }
  }

  backtoHome(): void {
    this.router.navigate(['/home']);
  }

}

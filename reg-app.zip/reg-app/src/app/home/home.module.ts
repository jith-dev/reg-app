import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home.component';
import { UserComponent } from '../user/user.component';
import { UserService } from '../user/user.service';
import { ReactiveFormsModule, FormControl, FormsModule  } from '@angular/forms';

@NgModule({
  declarations: [
    HomeComponent,
    UserComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forChild([
      { path: "home", component: HomeComponent }
    ])
  ],
  providers: [UserService],
})
export class HomeModule { }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user/user.service';
import { DataService } from '../data.service'


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  title = 'reg-app';
  url: string = '';
  usersList: any;
  usersDetail: any=[];

  constructor(private router: Router,  private user: UserService,private data: DataService) { }

  ngOnInit(): void {
    this.user.getUsers().subscribe((data:any) => {
      this.data.changeMessage(JSON.stringify(data.results));
      this.usersList = data.results;
      this.listAllUsers();
    });
  }

  register(): void {
    this.router.navigate(['/register']);
  }

  listAllUsers(): void {
    debugger;
    this.data.currentMessage.subscribe(data => {
      this.usersDetail = [];
      const usersInfo = JSON.parse(data);
      for(let i=0; i<usersInfo.length; i++){
        console.log(usersInfo[i].user.name.first != undefined);
        let name = (usersInfo[i].user.name.first != undefined) ? 
                        usersInfo[i].user.name.first:usersInfo[i].user.name.last;
        this.usersDetail.push(name);
      }

    });
  }

}

import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DataService } from '../data.service';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  title = 'reg-app';
  profileData: string;
  name: string;
  email: string;
  telephone: string;
  place: string;
  personalInterest: string;
  age: string;
  imageBase64: string;

  constructor(private data: DataService, private router: Router) { }

  ngOnInit() {
    this.data.currentMessage.subscribe(data => {
      this.profileData = data;
      const info = JSON.parse(this.profileData);
      this.name = info['firstName'] + ' ' + info['lastName'];
      this.email = info['email'];
      this.telephone = info['telephone'];
      this.place = info['cityName'] != '' ? info['cityName'].split(':')[1] : '';
      if (info['interests'].length > 0) {
        let hobby = [];
        info['interests'].forEach(element => {
          hobby.push(element['name']);
        });
        this.personalInterest = hobby.join();
        if (info['age'] == '0') {
          this.age = "13";
        } else if (info['age'] == '20') {
          this.age = "20";
        } else if (info['age'] == '30') {
          this.age = "30";
        } else {
          this.age = "45";
        }
      }
      this.imageBase64 = info['imageBase64'];
    })
  }

  editProfile(): void {
    let jsonData = JSON.parse(this.profileData);
    jsonData.imageBase64 = this.imageBase64;
    console.log(jsonData);
    this.data.changeMessage(JSON.stringify(jsonData));
    this.router.navigate(['/edit', 1]);
  }

  onselectFile(e: any): void {
    if (e.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      this.imageBase64 = '';
      reader.onload = (event: any) => {
        this.imageBase64 = event.target.result;
      }
    }
  }

  backtoHome(): void {
    this.router.navigate(['/home']);
  }

}
